/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: mysql    Database: ecoride_db
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `action_type` varchar(100) NOT NULL,
  `table_name` varchar(100) DEFAULT NULL,
  `record_id` int DEFAULT NULL,
  `old_values` json DEFAULT NULL,
  `new_values` json DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_action` (`action_type`),
  KEY `idx_date` (`created_at`),
  KEY `idx_table_record` (`table_name`,`record_id`),
  CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

LOCK TABLES `activity_logs` WRITE;
/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ride_id` int NOT NULL,
  `passenger_id` int NOT NULL,
  `seats_booked` tinyint NOT NULL DEFAULT '1',
  `booking_status` enum('pending','confirmed','cancelled','completed','dispute') DEFAULT 'confirmed',
  `total_price` decimal(8,2) NOT NULL,
  `booking_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `cancellation_date` datetime DEFAULT NULL,
  `cancellation_reason` text,
  `passenger_rating` tinyint DEFAULT NULL,
  `driver_rating` tinyint DEFAULT NULL,
  `passenger_review` text,
  `driver_review` text,
  `dispute_reason` text,
  `is_passenger_validated` tinyint(1) DEFAULT '0',
  `is_driver_validated` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_passenger_ride` (`ride_id`,`passenger_id`),
  KEY `idx_ride` (`ride_id`),
  KEY `idx_passenger` (`passenger_id`),
  KEY `idx_status` (`booking_status`),
  KEY `idx_booking_date` (`booking_date`),
  KEY `idx_bookings_stats` (`booking_date`,`booking_status`,`total_price`),
  CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`passenger_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookings_chk_1` CHECK ((`passenger_rating` between 1 and 5)),
  CONSTRAINT `bookings_chk_2` CHECK ((`driver_rating` between 1 and 5)),
  CONSTRAINT `chk_seats_booked` CHECK ((`seats_booked` >= 1)),
  CONSTRAINT `chk_total_price` CHECK ((`total_price` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
INSERT INTO `bookings` VALUES
(1,1,7,1,'confirmed',35.00,'2025-09-18 13:12:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(2,1,8,1,'confirmed',35.00,'2025-09-18 13:12:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(3,2,7,1,'confirmed',28.00,'2025-09-18 13:12:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(4,3,8,2,'confirmed',84.00,'2025-09-18 13:12:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,'2025-09-18 13:12:49','2025-09-18 13:12:49');
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `prevent_self_booking` BEFORE INSERT ON `bookings` FOR EACH ROW BEGIN
    DECLARE v_driver_id INT;
    SELECT driver_id INTO v_driver_id FROM rides WHERE id = NEW.ride_id;
    
    IF v_driver_id = NEW.passenger_id THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Un chauffeur ne peut pas réserver son propre trajet';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `notification_type` enum('info','success','warning','error') DEFAULT 'info',
  `is_read` tinyint(1) DEFAULT '0',
  `related_table` varchar(100) DEFAULT NULL,
  `related_id` int DEFAULT NULL,
  `action_url` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `read_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_unread` (`is_read`),
  KEY `idx_type` (`notification_type`),
  KEY `idx_created` (`created_at`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviews` (
  `id` int NOT NULL AUTO_INCREMENT,
  `booking_id` int NOT NULL,
  `reviewer_id` int NOT NULL,
  `reviewed_user_id` int NOT NULL,
  `rating` tinyint NOT NULL,
  `comment` text,
  `review_type` enum('driver_review','passenger_review') NOT NULL,
  `is_approved` tinyint(1) DEFAULT NULL,
  `approved_by` int DEFAULT NULL,
  `approval_date` datetime DEFAULT NULL,
  `rejection_reason` text,
  `is_public` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_booking_reviewer` (`booking_id`,`reviewer_id`),
  KEY `reviewer_id` (`reviewer_id`),
  KEY `approved_by` (`approved_by`),
  KEY `idx_reviewed_user` (`reviewed_user_id`),
  KEY `idx_approval_status` (`is_approved`),
  KEY `idx_public` (`is_public`),
  KEY `idx_created_date` (`created_at`),
  CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviews_ibfk_3` FOREIGN KEY (`reviewed_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviews_ibfk_4` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`),
  CONSTRAINT `reviews_chk_1` CHECK ((`rating` between 1 and 5))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `ride_details`
--

DROP TABLE IF EXISTS `ride_details`;
/*!50001 DROP VIEW IF EXISTS `ride_details`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `ride_details` AS SELECT
 1 AS `id`,
  1 AS `departure_city`,
  1 AS `arrival_city`,
  1 AS `departure_datetime`,
  1 AS `estimated_arrival_datetime`,
  1 AS `price_per_seat`,
  1 AS `available_seats`,
  1 AS `total_seats`,
  1 AS `description`,
  1 AS `smoking_allowed`,
  1 AS `pets_allowed`,
  1 AS `driver_pseudo`,
  1 AS `driver_photo`,
  1 AS `driver_rating`,
  1 AS `total_rides_as_driver`,
  1 AS `brand`,
  1 AS `model`,
  1 AS `color`,
  1 AS `fuel_type`,
  1 AS `is_ecological`,
  1 AS `status_name`,
  1 AS `booked_seats` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `ride_statuses`
--

DROP TABLE IF EXISTS `ride_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ride_statuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status_name` varchar(50) NOT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `status_name` (`status_name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ride_statuses`
--

LOCK TABLES `ride_statuses` WRITE;
/*!40000 ALTER TABLE `ride_statuses` DISABLE KEYS */;
INSERT INTO `ride_statuses` VALUES
(1,'created','Covoiturage crÃ©Ã©, en attente de participants','2025-09-18 13:12:49'),
(2,'confirmed','Covoiturage confirmÃ© avec des participants','2025-09-18 13:12:49'),
(3,'started','Covoiturage en cours','2025-09-18 13:12:49'),
(4,'completed','Covoiturage terminÃ© avec succÃ¨s','2025-09-18 13:12:49'),
(5,'cancelled','Covoiturage annulÃ©','2025-09-18 13:12:49'),
(6,'dispute','Covoiturage en litige','2025-09-18 13:12:49');
/*!40000 ALTER TABLE `ride_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rides`
--

DROP TABLE IF EXISTS `rides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rides` (
  `id` int NOT NULL AUTO_INCREMENT,
  `driver_id` int NOT NULL,
  `vehicle_id` int NOT NULL,
  `departure_city` varchar(255) NOT NULL,
  `departure_address` text,
  `arrival_city` varchar(255) NOT NULL,
  `arrival_address` text,
  `departure_datetime` datetime NOT NULL,
  `estimated_arrival_datetime` datetime DEFAULT NULL,
  `price_per_seat` decimal(8,2) NOT NULL,
  `available_seats` tinyint NOT NULL,
  `total_seats` tinyint NOT NULL,
  `status_id` int NOT NULL DEFAULT '1',
  `duration_minutes` int DEFAULT NULL,
  `distance_km` int DEFAULT NULL,
  `description` text,
  `driver_preferences` text,
  `smoking_allowed` tinyint(1) DEFAULT '0',
  `pets_allowed` tinyint(1) DEFAULT '0',
  `music_allowed` tinyint(1) DEFAULT '1',
  `is_recurrent` tinyint(1) DEFAULT '0',
  `recurrence_pattern` varchar(50) DEFAULT NULL,
  `platform_commission` decimal(8,2) DEFAULT '2.00',
  `actual_start_time` datetime DEFAULT NULL,
  `actual_end_time` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `vehicle_id` (`vehicle_id`),
  KEY `idx_driver` (`driver_id`),
  KEY `idx_departure_city` (`departure_city`),
  KEY `idx_arrival_city` (`arrival_city`),
  KEY `idx_departure_date` (`departure_datetime`),
  KEY `idx_status` (`status_id`),
  KEY `idx_available_seats` (`available_seats`),
  KEY `idx_search_route` (`departure_city`,`arrival_city`,`departure_datetime`),
  KEY `idx_ride_search` (`departure_city`,`arrival_city`,`departure_datetime`,`available_seats`,`status_id`),
  KEY `idx_rides_stats` (`departure_datetime`,`status_id`,`driver_id`),
  CONSTRAINT `rides_ibfk_1` FOREIGN KEY (`driver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rides_ibfk_2` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`),
  CONSTRAINT `rides_ibfk_3` FOREIGN KEY (`status_id`) REFERENCES `ride_statuses` (`id`),
  CONSTRAINT `chk_dates` CHECK (((`estimated_arrival_datetime` is null) or (`estimated_arrival_datetime` > `departure_datetime`))),
  CONSTRAINT `chk_price` CHECK ((`price_per_seat` >= 0)),
  CONSTRAINT `chk_seats` CHECK (((`available_seats` >= 0) and (`available_seats` <= `total_seats`)))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rides`
--

LOCK TABLES `rides` WRITE;
/*!40000 ALTER TABLE `rides` DISABLE KEYS */;
INSERT INTO `rides` VALUES
(1,4,1,'Paris','12 Rue de Rivoli, 75001 Paris','Lyon','Place Bellecour, 69002 Lyon','2025-09-15 14:00:00','2025-09-15 18:30:00',35.00,3,4,1,270,465,'Trajet Ã©cologique Paris-Lyon en Tesla. Musique d\'ambiance et bonne humeur !',NULL,0,1,1,0,NULL,2.00,NULL,NULL,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(2,4,2,'Lyon','Gare Part-Dieu, 69003 Lyon','Marseille','Gare Saint-Charles, 13001 Marseille','2025-09-16 09:00:00','2025-09-16 12:15:00',28.00,2,3,1,195,315,'Trajet matinal Lyon-Marseille. VÃ©hicule 100% Ã©lectrique !',NULL,0,0,1,0,NULL,2.00,NULL,NULL,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(3,5,3,'Paris','Porte de Versailles, 75015 Paris','Bordeaux','Place des Quinconces, 33000 Bordeaux','2025-09-17 08:00:00','2025-09-17 13:45:00',42.00,3,4,1,345,580,'Paris-Bordeaux en vÃ©hicule hybride. ArrÃªt possible aire de repos.',NULL,0,1,1,0,NULL,2.00,NULL,NULL,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(4,5,4,'Toulouse','Place du Capitole, 31000 Toulouse','Montpellier','Place de la ComÃ©die, 34000 Montpellier','2025-09-18 16:30:00','2025-09-18 19:00:00',22.00,4,4,1,150,245,'Trajet Toulouse-Montpellier en fin de journÃ©e.',NULL,0,0,1,0,NULL,2.00,NULL,NULL,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(5,6,5,'Lille','Gare Lille Europe, 59000 Lille','Bruxelles','Gare Centrale, 1000 Bruxelles','2025-09-19 10:15:00','2025-09-19 12:00:00',18.00,4,4,1,105,115,'Trajet international Lille-Bruxelles en Nissan Leaf Ã©lectrique. Voyage Ã©cologique garanti !',NULL,0,1,1,0,NULL,2.00,NULL,NULL,'2025-09-18 13:12:49','2025-09-18 13:12:49');
/*!40000 ALTER TABLE `rides` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_preferences`
--

DROP TABLE IF EXISTS `user_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_preferences` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `preference_key` varchar(100) NOT NULL,
  `preference_value` text NOT NULL,
  `is_mandatory` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_preference` (`user_id`,`preference_key`),
  KEY `idx_user` (`user_id`),
  KEY `idx_key` (`preference_key`),
  CONSTRAINT `user_preferences_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_preferences`
--

LOCK TABLES `user_preferences` WRITE;
/*!40000 ALTER TABLE `user_preferences` DISABLE KEYS */;
INSERT INTO `user_preferences` VALUES
(1,4,'smoking_allowed','false',1,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(2,4,'pets_allowed','true',0,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(3,4,'music_style','Pop, Jazz',0,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(4,4,'conversation_level','ModÃ©rÃ©e',0,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(5,5,'smoking_allowed','false',1,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(6,5,'pets_allowed','true',0,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(7,5,'break_frequency','Toutes les 2h',0,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(8,6,'smoking_allowed','false',1,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(9,6,'pets_allowed','true',1,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(10,6,'ecological_discussion','EncouragÃ©e',0,'2025-09-18 13:12:49','2025-09-18 13:12:49');
/*!40000 ALTER TABLE `user_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) NOT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_name` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` VALUES
(1,'admin','Administrateur systÃ¨me - accÃ¨s complet','2025-09-18 13:12:49'),
(2,'employee','EmployÃ© - modÃ©ration et support','2025-09-18 13:12:49'),
(3,'user','Utilisateur standard - passager/chauffeur','2025-09-18 13:12:49'),
(4,'visitor','Visiteur - accÃ¨s limitÃ© en lecture seule','2025-09-18 13:12:49');
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `user_stats`
--

DROP TABLE IF EXISTS `user_stats`;
/*!50001 DROP VIEW IF EXISTS `user_stats`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `user_stats` AS SELECT
 1 AS `id`,
  1 AS `pseudo`,
  1 AS `email`,
  1 AS `credits`,
  1 AS `rating_average`,
  1 AS `total_rides_as_driver`,
  1 AS `total_rides_as_passenger`,
  1 AS `is_driver`,
  1 AS `is_passenger`,
  1 AS `rides_created`,
  1 AS `bookings_made`,
  1 AS `total_spent` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `pseudo` varchar(100) NOT NULL,
  `role_id` int NOT NULL DEFAULT '2',
  `credits` int DEFAULT '20',
  `is_driver` tinyint(1) DEFAULT '0',
  `is_passenger` tinyint(1) DEFAULT '1',
  `profile_picture` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `is_verified` tinyint(1) DEFAULT '0',
  `rating_average` decimal(2,1) DEFAULT '0.0',
  `total_rides_as_driver` int DEFAULT '0',
  `total_rides_as_passenger` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `pseudo` (`pseudo`),
  KEY `idx_email` (`email`),
  KEY `idx_pseudo` (`pseudo`),
  KEY `idx_role` (`role_id`),
  KEY `idx_active` (`is_active`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `user_roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'admin@ecoride.fr','$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/0.MioPuHiuK','AdminEcoRide',1,1000,0,0,NULL,'+33123456789',1,1,0.0,0,0,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(2,'employe1@ecoride.fr','$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/0.MioPuHiuK','ModeratorJoe',2,100,0,0,NULL,'+33123456790',1,1,0.0,0,0,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(3,'employe2@ecoride.fr','$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/0.MioPuHiuK','SupportSarah',2,100,0,0,NULL,'+33123456791',1,1,0.0,0,0,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(4,'marie.dupont@email.com','$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/0.MioPuHiuK','MarieDriveGreen',3,45,1,1,NULL,'+33612345678',1,1,0.0,0,0,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(5,'jean.martin@email.com','$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/0.MioPuHiuK','JeanEcoDriver',3,62,1,1,NULL,'+33687654321',1,1,0.0,0,0,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(6,'sophie.bernard@email.com','$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/0.MioPuHiuK','SophieVerte',3,38,1,1,NULL,'+33698765432',1,1,0.0,0,0,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(7,'pierre.durand@email.com','$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/0.MioPuHiuK','PierreVoyage',3,28,0,1,NULL,'+33654321098',1,1,0.0,0,0,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(8,'claire.moreau@email.com','$2y$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/0.MioPuHiuK','ClaireEco',3,33,0,1,NULL,'+33643210987',1,1,0.0,0,0,'2025-09-18 13:12:49','2025-09-18 13:12:49');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehicles`
--

DROP TABLE IF EXISTS `vehicles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehicles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `brand` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  `color` varchar(50) NOT NULL,
  `license_plate` varchar(20) NOT NULL,
  `first_registration` date NOT NULL,
  `fuel_type` enum('essence','diesel','electrique','hybride') NOT NULL,
  `seats_available` tinyint NOT NULL,
  `is_ecological` tinyint(1) GENERATED ALWAYS AS ((`fuel_type` = _utf8mb4'electrique')) STORED,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `license_plate` (`license_plate`),
  KEY `idx_user` (`user_id`),
  KEY `idx_ecological` (`is_ecological`),
  KEY `idx_active` (`is_active`),
  CONSTRAINT `vehicles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `vehicles_chk_1` CHECK ((`seats_available` between 1 and 8))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicles`
--

LOCK TABLES `vehicles` WRITE;
/*!40000 ALTER TABLE `vehicles` DISABLE KEYS */;
INSERT INTO `vehicles` VALUES
(1,4,'Tesla','Model 3','Blanche','AB-123-CD','2022-03-15','electrique',4,1,1,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(2,4,'Renault','ZOE','Bleue','EF-456-GH','2021-11-20','electrique',3,1,1,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(3,5,'Toyota','Prius','Grise','IJ-789-KL','2020-06-10','hybride',4,0,1,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(4,5,'Peugeot','308','Noire','MN-012-OP','2019-04-22','essence',4,0,1,'2025-09-18 13:12:49','2025-09-18 13:12:49'),
(5,6,'Nissan','Leaf','Verte','QR-345-ST','2023-01-08','electrique',4,1,1,'2025-09-18 13:12:49','2025-09-18 13:12:49');
/*!40000 ALTER TABLE `vehicles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `ride_details`
--

/*!50001 DROP VIEW IF EXISTS `ride_details`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ride_details` AS select `r`.`id` AS `id`,`r`.`departure_city` AS `departure_city`,`r`.`arrival_city` AS `arrival_city`,`r`.`departure_datetime` AS `departure_datetime`,`r`.`estimated_arrival_datetime` AS `estimated_arrival_datetime`,`r`.`price_per_seat` AS `price_per_seat`,`r`.`available_seats` AS `available_seats`,`r`.`total_seats` AS `total_seats`,`r`.`description` AS `description`,`r`.`smoking_allowed` AS `smoking_allowed`,`r`.`pets_allowed` AS `pets_allowed`,`u`.`pseudo` AS `driver_pseudo`,`u`.`profile_picture` AS `driver_photo`,`u`.`rating_average` AS `driver_rating`,`u`.`total_rides_as_driver` AS `total_rides_as_driver`,`v`.`brand` AS `brand`,`v`.`model` AS `model`,`v`.`color` AS `color`,`v`.`fuel_type` AS `fuel_type`,`v`.`is_ecological` AS `is_ecological`,`rs`.`status_name` AS `status_name`,(`r`.`total_seats` - `r`.`available_seats`) AS `booked_seats` from (((`rides` `r` join `users` `u` on((`r`.`driver_id` = `u`.`id`))) join `vehicles` `v` on((`r`.`vehicle_id` = `v`.`id`))) join `ride_statuses` `rs` on((`r`.`status_id` = `rs`.`id`))) where ((`r`.`status_id` in (1,2)) and (`r`.`departure_datetime` > now()) and (`r`.`available_seats` > 0)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `user_stats`
--

/*!50001 DROP VIEW IF EXISTS `user_stats`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `user_stats` AS select `u`.`id` AS `id`,`u`.`pseudo` AS `pseudo`,`u`.`email` AS `email`,`u`.`credits` AS `credits`,`u`.`rating_average` AS `rating_average`,`u`.`total_rides_as_driver` AS `total_rides_as_driver`,`u`.`total_rides_as_passenger` AS `total_rides_as_passenger`,`u`.`is_driver` AS `is_driver`,`u`.`is_passenger` AS `is_passenger`,count(distinct `r`.`id`) AS `rides_created`,count(distinct `b`.`id`) AS `bookings_made`,coalesce(sum((case when (`b`.`booking_status` = 'completed') then `b`.`total_price` else 0 end)),0) AS `total_spent` from ((`users` `u` left join `rides` `r` on((`u`.`id` = `r`.`driver_id`))) left join `bookings` `b` on((`u`.`id` = `b`.`passenger_id`))) where (`u`.`role_id` = 3) group by `u`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-19  7:56:03
